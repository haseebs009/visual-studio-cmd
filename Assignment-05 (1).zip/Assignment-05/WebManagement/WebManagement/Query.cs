﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebManagement
{
    public class Query
    {
        

        public string Name   // property
        {
            get { return "Data Source=CMDLHRDB01;Initial Catalog=management;Persist Security Info=True;User ID=sa;Password=CureMD2022;"; }  // get method


        }


    }
}