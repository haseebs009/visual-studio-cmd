﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Services;
using Newtonsoft.Json;
using System.Web.Script.Serialization;

namespace WebManagement
{
    public partial class Items : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ItemName.Text = "";
            CostPrice.Text = "";
            SalePrice.Text = "";
        }
        [WebMethod]
        //adding the items
        public static string AddItems(string itemname,int costprice,int saleprice)
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);

            string sql = "insert into ItemsDet values('" + itemname + "','" + costprice + "','" + saleprice + "')";

            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            return "Success";
        }

        [WebMethod]
        //showing the items 
        public static string ShowItems()
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name); 
            string sql = "select id,name,costprice,saleprice from ItemsDet";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();

            cmd.CommandType = CommandType.Text;
            List<Item> item = new List<Item>();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                Item itm = new Item();

                itm.Id = Convert.ToInt32(dr["id"]);
                itm.ItemName = dr["name"].ToString(); ;
                itm.CostPrice = Convert.ToInt32(dr["costprice"]);
                itm.SalePrice = Convert.ToInt32(dr["saleprice"]);

                item.Add(itm);

            }

            con.Close();
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(item);

        
        }

        [WebMethod]
        //Deleting the items
        public static void DeleteItem(int data)
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            string sql = "delete from ItemsDet where id = '" + data + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        //Editing the items
        [WebMethod]
        public static List<Item> EditItems(int data)
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            string sql = "select * from ItemsDet where id = '" + data + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();

            cmd.CommandType = CommandType.Text;
            List<Item> item = new List<Item>();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                Item itm = new Item();

                itm.Id = Convert.ToInt32(dr["id"]);
                itm.ItemName = dr["name"].ToString(); ;
                itm.CostPrice = Convert.ToInt32(dr["costprice"]);
                itm.SalePrice = Convert.ToInt32(dr["saleprice"]);

                item.Add(itm);

            }

            con.Close();

            return item;
        }
        //Updating the Items
        [WebMethod]
        public static string UpdateItems(string itemname,int costprice,int saleprice,int Id)
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);

            string sql = "update ItemsDet set name ='" + itemname + "',costprice='" + costprice + "',saleprice='" + saleprice + "' where id = '" + Id + "'";

            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            return "Success";
        }


    }
}