﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Services;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using System.Data.SqlClient;
namespace WebManagement
{
    public partial class UserManagement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        
        protected void AddUser_Click(object sender, EventArgs e)
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            string sql = "insert into UserRecord values('" + UserInput.Text + "','" + UserPassword.Text + "')";

            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        protected void Back_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }
    }
}