﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebManagement
{
    //Class For BillGeneration
    public class BillGeneration
    {
        //Fields or accessors of current class

        public int Id { get; set; }
        public string ItemName { get; set; }
        
        public int SalePrice { get; set; }  
    }
}