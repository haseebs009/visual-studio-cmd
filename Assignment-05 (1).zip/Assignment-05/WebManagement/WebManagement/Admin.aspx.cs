﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebManagement
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Logout Admin Click Function 
        protected void Unnamed_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("Login.aspx");
        }
        //User Page Event
        protected void Unnamed_Click1(object sender, EventArgs e)
        {
            Response.Redirect("UserManagement.aspx");
        }
        //Event Calling Function by its name
        protected void Customer_Click(object sender, EventArgs e)
        {
            Response.Redirect("Coustmers.aspx");
        }
        protected void Item_Click(object sender, EventArgs e)
        {
            Response.Redirect("Items.aspx");
        }
    }
}