﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebManagement
{
    public class Customers
    {   //Fields or accessors of Customer Class
        public int Id { get; set; }
        public string CustomerName { get; set; }

        public string CustomerEmail { get; set; }

        public string CustomerAddress { get; set; }

    }
}