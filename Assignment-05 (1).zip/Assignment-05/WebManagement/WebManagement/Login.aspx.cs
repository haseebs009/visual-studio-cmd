﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using System.Data.SqlClient;
using System.Data;
namespace WebManagement
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public class UserDetail
        {
            public string UserName { get; set; }

            public string Password { get; set; }
        } 

        protected void Button1_Click(object sender, EventArgs e)
        {
            //Admin Login
            //Checking Validity on the server side of username and password
            if (DropdownList1.SelectedValue == "Admin")
            {
                if (TypeUserName.Text.ToLower().Trim() == "polar" && TypePassword.Text.ToLower().Trim() == "vezli")
                {
                    Session["UserName"] = TypeUserName.Text;
                    Session["Password"] = TypePassword.Text;
                    Response.Redirect("Admin.aspx");
                }
                if (TypeUserName.Text.ToLower().Trim() != "polar")
                {
                    Label1.Text = "Enter Your Valid Id";
                    TypeUserName.Text = "";
                }
                if (TypePassword.Text.ToLower().Trim() != "vezli")
                {
                    Label2.Text = "Enter Your Valid Password";
                    TypePassword.Text = "";
                }
            }
            else
            {   //User login
                Query query = new Query();
                SqlConnection con = new SqlConnection(query.Name);
                string sql = "select username, userpwd from UserRecord ";
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();

                cmd.CommandType = CommandType.Text;
                List<UserDetail> user = new List<UserDetail>();
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {

                    UserDetail usr = new UserDetail();

                    usr.UserName = dr["username"].ToString();
                    usr.Password = dr["userpwd"].ToString();

                    user.Add(usr);

                }

                con.Close();
                for (int i = 0; i < user.Count; i++)
                {
                    
                    if (TypeUserName.Text.ToLower().Trim() == user[i].UserName.ToLower().Trim())
                    {
                        if (TypePassword.Text.ToLower().Trim() == user[i].Password.ToLower().Trim())
                        {
                            Response.Redirect("User.aspx");
                            return;
                        }
                        else
                        {
                            TypePassword.Text = "";
                            Label2.Text = "Wrong Password";
                        }
                        
                    }
                    else
                    {
                        Label3.Text = "Invalid User";
                    }
                }

            }
        }
    }
}