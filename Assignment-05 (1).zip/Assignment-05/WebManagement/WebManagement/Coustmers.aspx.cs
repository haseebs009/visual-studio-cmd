﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Services;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
namespace WebManagement
{
    public partial class Coustmers : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Adding Customer
        [WebMethod]
        public static string AddCustomer(string customername, string customeremail, string customeraddress)
        {   //Connection
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            //Query
            string sql = "insert into Customer values('" + customername + "','" + customeremail + "','" + customeraddress + "')";

            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            return "Success";
        }
        //Show Customers in dataTable
        [WebMethod]
        public static string ShowCoustmers()
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            string sql = "select id,CustomerName,CustomerEmail,CustomerAddress from Customer ";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();

            
            cmd.CommandType = CommandType.Text;
            List<Customers> customer = new List<Customers>();
            SqlDataReader dr = cmd.ExecuteReader();
            //Data Reading
            while (dr.Read())
            {

                Customers custom = new Customers();

                custom.Id = Convert.ToInt32(dr["id"].ToString());
                custom.CustomerName = dr["CustomerName"].ToString();
                custom.CustomerEmail = dr["CustomerEmail"].ToString();
                custom.CustomerAddress = dr["CustomerAddress"].ToString();
                
                customer.Add(custom);

            }

            con.Close();
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(customer);

        }
        //Deleting the Customer
        [WebMethod]
        public static void DeleteCustomer(int data)
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            string sql = "delete from Customer where id = '" + data + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }
        //Editing The Customer
        [WebMethod]
        public static List<Customers> EditCustomer(int data)
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            string sql = "Select * from Customer where id = '" + data + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();

            cmd.CommandType = CommandType.Text;
            List<Customers> customer = new List<Customers>();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                Customers custom = new Customers();

                custom.Id = Convert.ToInt32(dr["id"].ToString());
                custom.CustomerName = dr["CustomerName"].ToString();
                custom.CustomerEmail = dr["CustomerEmail"].ToString();
                custom.CustomerAddress = dr["CustomerAddress"].ToString();

                customer.Add(custom);

            }

            con.Close();
           
            return customer;
        }
        //Updating the customer
        [WebMethod]
        public static void UpdateCustomer(string customername, string customeremail, string customeraddress,int Id)
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            string sql = "update Customer set CustomerName = '" + customername + "',CustomerEmail = '" + customeremail + "',CustomerAddress = '" + customeraddress + "' where id = '" + Id + "'";

            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }


    }
}