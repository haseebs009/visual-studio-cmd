﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebManagement
{
    public partial class User : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Logout Event
        protected void Unnamed_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("Login.aspx");
        }
        protected void Coustmer_Click(object sender, EventArgs e)
        {
            Response.Redirect("Coustmers.aspx");
        }
        protected void Items_Click(object sender, EventArgs e)
        {
            Response.Redirect("Items.aspx");
        }

        protected void Unnamed_Click1(object sender, EventArgs e)
        {
            Response.Redirect("GenerateBill.aspx");
        }
    }
}