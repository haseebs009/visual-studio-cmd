﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Services;
using System.Web.Script.Serialization;

namespace WebManagement
{
    public partial class GenerateBill : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static List<string> GetCoustmers(string term)
       {
            //Connection
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            //Query
            string sql = "select CustomerName,CustomerEmail,CustomerAddress from Customer ";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            List<Customers> customer = new List<Customers>();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                Customers custom = new Customers();

                
                custom.CustomerName = dr["CustomerName"].ToString();
                custom.CustomerEmail = dr["CustomerEmail"].ToString();
                custom.CustomerAddress = dr["CustomerAddress"].ToString();

                customer.Add(custom);

            }

            con.Close();
            List<string> list = new List<string>();
            var customerCount = customer.Count;
            for (int i = 0; i < customerCount; i++)
            {
                if (customer[i].CustomerName.ToLower().Contains(term.ToLower()))
                {   // Sending Data into new List
                    list.Add(customer[i].CustomerName.ToLower());
                }
            }
            return list;
        }

        [WebMethod]

        public static List<string> ShowItems(string term)
        {
            //Connection
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            //Query
            string sql = "select id,name,costprice,saleprice from ItemsDet ";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();

            cmd.CommandType = CommandType.Text;
            List<Item> item = new List<Item>();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                Item itm = new Item();

                itm.Id = Convert.ToInt32(dr["id"]);
                itm.ItemName = dr["name"].ToString(); ;
                itm.CostPrice = Convert.ToInt32(dr["costprice"]);
                itm.SalePrice = Convert.ToInt32(dr["saleprice"]);

                item.Add(itm);

            }

            con.Close();

            List<string> list = new List<string>();
            var itemCount = item.Count;
            for (int i = 0; i < itemCount; i++)
            {
                if (item[i].ItemName.ToLower().Contains(term.ToLower()))
                {   // Sending Data into new List
                    list.Add(item[i].ItemName.ToLower());
                }
            }
            return list;

        }

        [WebMethod]

        public static string GetItems(string itmname)
        {
            //Connection
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            //Query
            string sql = "select name,saleprice from ItemsDet where name = '" + itmname + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();

            cmd.CommandType = CommandType.Text;
            List<BillGeneration> bill = new List<BillGeneration>();
            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                BillGeneration bil = new BillGeneration();


                bil.ItemName = dr["name"].ToString(); ;
                bil.SalePrice = Convert.ToInt32(dr["saleprice"]);

                bill.Add(bil);

            }
            con.Close();

            sql = "insert into Bill values('" + bill[0].ItemName + "','" + bill[0].SalePrice + "')";

            SqlCommand comd = new SqlCommand(sql, con);
            con.Open();
            comd.ExecuteNonQuery();
            con.Close();


            return "Success";
        }

        [WebMethod]

        public static string ShowBill()
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            string sql = "select id,Name,Price from Bill ";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();


            cmd.CommandType = CommandType.Text;
            List<BillGeneration> bill = new List<BillGeneration>();
            SqlDataReader dr = cmd.ExecuteReader();
            //Data Reading
            while (dr.Read())
            {

                BillGeneration bil = new BillGeneration();

                bil.Id = Convert.ToInt32(dr["id"]);
                bil.ItemName = dr["Name"].ToString();
                bil.SalePrice = Convert.ToInt32(dr["Price"]);

                bill.Add(bil);

            }

            con.Close();
            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(bill);

        }
        [WebMethod]

        public static void DeleteBill(int data)
        {
            Query query = new Query();
            SqlConnection con = new SqlConnection(query.Name);
            string sql = "delete from Bill where id = '" + data + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
        }

    }

}