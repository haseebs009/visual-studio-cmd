﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Runtime.Caching;

namespace StudentDataApi.Controllers
{
    public class StudentsData
    {
        int id { get; set; }
        string name { get; set; }
        int age { get; set; }
        string address { get; set; }
        public List<StudentsData> getStudentData()

        {

            List<StudentsData> studentsList = new List<StudentsData>();
            ObjectCache cache = MemoryCache.Default;
            if (cache["Student"] == null)
            {
                DatabaseConnection obj = new DatabaseConnection();
                SqlConnection con = obj.GetConnection();
                obj.CloseConnection();
                SqlDataReader dataReader;
                try
                {
                    using (con)
                    {
                        con.Open();
                        SqlCommand command = new SqlCommand("getStudents", con);
                        command.CommandType = CommandType.StoredProcedure;
                        dataReader = command.ExecuteReader();
                        while (dataReader.Read())
                        {
                            StudentsData objStudent = new StudentsData { id = dataReader.GetInt32(0), name = dataReader[1].ToString(), age = dataReader.GetInt32(2), address = dataReader[3].ToString() };
                            studentsList.Add(objStudent);
                        }
                        con.Close();
                    }
                    dataReader.Close();
                    var cacheItemPolicy = new CacheItemPolicy
                    {
                        AbsoluteExpiration = DateTimeOffset.Now.AddDays(1),
                    };
                    var cacheItem = new CacheItem("Student", studentsList);
                    cache.Add(cacheItem, cacheItemPolicy);
                }
                catch (SqlException ex)
                {
                    Console.WriteLine("Exception While Reading data from database " + ex);
                }
            }
            else
            {
                studentsList = (List<StudentsData>)cache.Get("Student"); 
            }
            return studentsList;
        }
    }
}