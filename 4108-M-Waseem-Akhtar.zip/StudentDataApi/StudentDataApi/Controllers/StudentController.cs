﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace StudentDataApi.Controllers
{
    public class StudentController : ApiController
    {
        [Route("student")]
        public List<StudentsData> Get()
        {
            StudentsData data = new StudentsData();
            List<StudentsData> studentsList = new List<StudentsData>();
            studentsList = data.getStudentData();
            return studentsList;
        }
    }
}
