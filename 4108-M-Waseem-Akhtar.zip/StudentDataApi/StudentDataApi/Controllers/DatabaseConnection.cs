﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace StudentDataApi.Controllers
{
    public class DatabaseConnection
    {
        string connectionString;
        SqlConnection con;
        private void CreateConnection()
        {
            try
            {
                connectionString = @"Data Source=CMDLHRDB01;Initial Catalog=Students;Persist Security Info=True;User ID=sa;Password=CureMD2022";
                con = new SqlConnection(connectionString);
                con.Open();
            }
            catch (SqlException ex)
            {
                Console.WriteLine("Following Exception Occured While Making Connection " + ex);
            }
        }
        private bool IsConnected()
        {
            if (con == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public SqlConnection GetConnection()
        {
            if (IsConnected())
            {
                return con;
            }
            else
            {
                CreateConnection();
                return con;
            }
        }
        public void CloseConnection()
        {
            con.Close();
        }
    }
}