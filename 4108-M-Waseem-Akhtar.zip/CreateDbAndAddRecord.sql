create database Students;
use Students;
create table StudentsInfo(
id int identity(1,1) primary key,
name varchar(50) not null,
age int ,
address varchar(50),
);

insert into StudentsInfo values('Waseem',26,'Lahore');
insert into StudentsInfo values('lucky',28,'Lahore');
insert into StudentsInfo values('wasi',21,'Peshawar');
insert into StudentsInfo values('sulatn',34,'Faisalabad');
insert into StudentsInfo values('ahmed',50,'Waqar');
insert into StudentsInfo values('sulman',36,'Lahore');
insert into StudentsInfo values('kamran',34,'Islamabad');
insert into StudentsInfo values('kaleem',11,'Lahore');

CREATE PROCEDURE getStudents
AS
begin
SELECT * FROM dbo.StudentsInfo
end

exec getStudents;

/*loop to insert 4000 bulk records */
DECLARE @i int = 0
WHILE @i < 4000 
BEGIN
    SET @i = @i + 1
    insert into StudentsInfo values('kaleem',11,'Lahore');
END